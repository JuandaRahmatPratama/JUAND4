<h1 align="center">Zero YT7 <img src="https://user-images.githubusercontent.com/1303154/88677602-1635ba80-d120-11ea-84d8-d263ba5fc3c0.gif" width="40px" alt=""><br></h1>
<p align="center">
<img src="https://i.ibb.co/YDYS80p/zero.jpg" />
</p>

<p align="center">

- 👼 My name is Zero YT7

- 🗣️ I am 18 years old 

- 🔭 I am Not programmer
 
- 😎 I am like Wibu
</p>

------

# ```BASE SC ZERO YT7```
<p align="center">
<a href="https://github.com/Zero-YT7/followers"><img title="Followers" src="https://img.shields.io/github/followers/Zero-YT7?color=red&style=flat-square"></a>
<a href="https://github.com/Zero-YT7/Base-ZeroYT7/stargazers/"><img title="Stars" src="https://img.shields.io/github/stars/Zero-YT7/Base-ZeroYT7?color=blue&style=flat-square"></a>
<a href="https://github.com/Zero-YT7/Base-ZeroYT7/network/members"><img title="Forks" src="https://img.shields.io/github/forks/Zero-YT7/Base-ZeroYT7?color=red&style=flat-square"></a>
<a href="https://github.com/Zero-YT7/Base-ZeroYT7/watchers"><img title="Watching" src="https://img.shields.io/github/watchers/Zero-YT7/Base-ZeroYT7?label=Watchers&color=blue&style=flat-square"></a>
<a href="https://github.com/Zero-YT7/Base-ZeroYT7"><img title="Open Source" src="https://badges.frapsoft.com/os/v2/open-source.svg?v=103"></a>
<a href="https://github.com/ZeroYT7/Base-ZeroYT7/"><img title="Size" src="https://img.shields.io/github/repo-size/Zero-YT7/Base-ZeroYT7?style=flat-square&color=green"></a>
<a href="https://hits.seeyoufarm.com"><img src="https://hits.seeyoufarm.com/api/count/incr/badge.svg?url=https%3A%2F%2Fgithub.com%2FZero-YT7%2FBase-ZeroYT7&count_bg=%2379C83D&title_bg=%23555555&icon=probot.svg&icon_color=%2300FF6D&title=hits&edge_flat=false"/></a>
<a href="https://github.com/Zero-YT7/Base-ZeroYT7/graphs/commit-activity"><img height="20" src="https://img.shields.io/badge/Maintained%3F-yes-green.svg"></a>&nbsp;&nbsp;
</p>
<p align='center'>
    </p>

-------

## ```FOLLOW ALL SOSIALMEDIA ME```
<p align="center">
<a href="https://instagram.com/ZeroYT7"><img src="https://img.shields.io/badge/Instagram-E4405F?style=for-the-badge&logo=instagram&logoColor=white"/> 
<a href="https://wa.me/6285157740529"><img src="https://img.shields.io/badge/WhatsApp-25D366?style=for-the-badge&logo=whatsapp&logoColor=white" />
<a href="https://youtube.com/ZeroYT7"><img src="https://img.shields.io/badge/YouTube Zero YT7-ff0000?style=for-the-badge&logo=youtube&logoColor=ff000000&link=https://youtube.com/ZeroYT7" /><br>
<a href="https://tiktok.com/@_zeroyt7"><img src="https://img.shields.io/badge/Tiktok Zero YT7-black?style=for-the-badge&logo=tiktok&logoColor=ff000000&link=https://tiktok.com/@zeroyt7" /></a>
</p>

## ```SETTING```

- Owner number [Here](https://github.com/Zero-YT7/Base-ZeroYT7/blob/master/setting.json#L4)
- Owner name [Here](https://github.com/Zero-YT7/Base-ZeroYT7/blob/master/setting.json#L13)
- Botname [Here](https://github.com/Zero-YT7/Base-ZeroYT7/blob/master/setting.json#L14)

## ```DONASI```

- [`SAWERIA`](https://saweria.co/ZeroYT7)

## ```GROUP BOT```

- [`GROUP WA`](https://chat.whatsapp.com/BM0HVJKYR2BI8JJUlQO2ue)

# Requirements
* [Node.js](https://nodejs.org/en/)
* [Git](https://git-scm.com/downloads)
* [FFmpeg](https://www.gyan.dev/ffmpeg/builds/) (for sticker command)
* [Libwebp](https://developers.google.com/speed/webp/download) (for sticker wm)

## For Termux
```bash
termux-setup-storage
apt update && apt upgrade
pkg install nodejs
pkg install git 
pkg install ffmpeg
pkg install libwebp 
pkg install imagemagick
pkg install bash
git clone https://github.com/Zero-YT7/Base-ZeroYT7.git
cd Base-ZeroYT7
npm install
npm start
```
## For Windows
```bash
git clone https://github.com/Zero-YT7/Base-ZeroYT7.git
cd Base-ZeroYT7
npm install
npm start
```
## For VPS
```bash
apt install nodejs 
apt install git 
apt apt install ffmpeg 
apt apt install libwebp 
apt apt install imagemagick
apt install bash
git clone https://github.com/Zero-YT7/Base-ZeroYT7.git
cd Base-ZeroYT7
npm install
npm start
```

