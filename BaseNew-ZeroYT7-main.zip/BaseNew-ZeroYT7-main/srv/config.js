{
"Lolkey": "YOUR APIKEY",
"Vhtear": "YOUR APIKEY",
"Xteam": "YOUR APIKEY",
"Zeks": "YOUR APIKEY",
"Nurutomo": "YOUR APIKEY",
"Zero": "ZeroYT7"
}